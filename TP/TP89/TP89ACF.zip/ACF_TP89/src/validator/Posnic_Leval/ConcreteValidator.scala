package validator.Posnic_Leval;
import bank._


// Automatic conversion of bank.message to tp89.messages and Nat to bank.Nat
object Converter{
  implicit def bank2message(m:bank.message):tp89.message=
    m match {
    case bank.Pay((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p)) => tp89.Pay((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))
    case bank.Ack((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p)) => tp89.Ack((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))
    case bank.Cancel((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i)))) => tp89.Cancel((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))))
  }
  
  implicit def trans2bankTrans(l:List[((Nat.nat,(Nat.nat,Nat.nat)),Nat.nat)]): List[((bank.Nat.nat,(bank.Nat.nat,bank.Nat.nat)),bank.Nat.nat)]=
    l match {
    case Nil => Nil
    case ((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))::r => ((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p))::trans2bankTrans(r)
  }
}

import Converter._


/* The object to complete */ 
class ConcreteValidator extends TransValidator{

  var bdd:(List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])=(List(),List())
	// TODO
	def process(m:message){
    
    bdd= tp89.traiterMessage(m,bdd)
  }

	// TODO
	def getValidTrans= tp89.export(bdd)

	// TODO
	def authors= "<POSNIC_LEVAL>"
}

//INSERT IMPORT HERE:
object HOL {

trait equal[A] {
  val `HOL.equal`: (A, A) => Boolean
}
def equal[A](a: A, b: A)(implicit A: equal[A]): Boolean = A.`HOL.equal`(a, b)

def eq[A : equal](a: A, b: A): Boolean = equal[A](a, b)

} /* object HOL */

object Code_Numeral {

def integer_of_nat(x0: Nat.nat): BigInt = x0 match {
  case Nat.Nata(x) => x
}

} /* object Code_Numeral */

object Nat {

abstract sealed class nat
final case class Nata(a: BigInt) extends nat

def equal_nata(m: nat, n: nat): Boolean =
  Code_Numeral.integer_of_nat(m) == Code_Numeral.integer_of_nat(n)

implicit def equal_nat: HOL.equal[nat] = new HOL.equal[nat] {
  val `HOL.equal` = (a: nat, b: nat) => equal_nata(a, b)
}

def zero_nat: nat = Nata(BigInt(0))

def less_eq_nat(m: nat, n: nat): Boolean =
  Code_Numeral.integer_of_nat(m) <= Code_Numeral.integer_of_nat(n)

} /* object Nat */

object Product_Type {

def equal_proda[A : HOL.equal, B : HOL.equal](x0: (A, B), x1: (A, B)): Boolean =
  (x0, x1) match {
  case ((x1, x2), (y1, y2)) => HOL.eq[A](x1, y1) && HOL.eq[B](x2, y2)
}

implicit def equal_prod[A : HOL.equal, B : HOL.equal]: HOL.equal[(A, B)] = new
  HOL.equal[(A, B)] {
  val `HOL.equal` = (a: (A, B), b: (A, B)) => equal_proda[A, B](a, b)
}

} /* object Product_Type */

object tp89 {

import /*implicits*/ Product_Type.equal_prod, Nat.equal_nat

abstract sealed class message
final case class Pay(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Ack(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Cancel(a: (Nat.nat, (Nat.nat, Nat.nat))) extends message

def export(x0: (List[((Nat.nat, (Nat.nat, Nat.nat)),
                       (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                 List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])):
      List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]
  =
  x0 match {
  case (tIdV, tr) => tr
}

def validate(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                   (Option[Nat.nat], (Option[Nat.nat], Boolean))),
              transaction: List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]
  =
  (x0, transaction) match {
  case ((transid, (Some(amc), (Some(amm), isAvailable))), transaction) =>
    (transid, amc) :: transaction
  case ((v, (None, vc)), transaction) => transaction
  case ((v, (vb, (None, ve))), transaction) => transaction
}

def isNotInTransaction(transid: (Nat.nat, (Nat.nat, Nat.nat)),
                        x1: List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]):
      Boolean
  =
  (transid, x1) match {
  case (transid, Nil) => true
  case (transid, (htransid, hn) :: ttr) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](htransid, transid))
      false else isNotInTransaction(transid, ttr))
}

def validable(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                    (Option[Nat.nat], (Option[Nat.nat], Boolean))),
               transaction: List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]):
      Boolean
  =
  (x0, transaction) match {
  case ((transid, (Some(amc), (Some(amm), isAvailable))), transaction) =>
    isAvailable &&
      (Nat.less_eq_nat(amm, amc) &&
        (! (Nat.equal_nata(amc, Nat.zero_nat)) &&
          isNotInTransaction(transid, transaction)))
  case ((v, (None, vc)), uv) => false
  case ((v, (vb, (None, ve))), uv) => false
}

def keepHeader(keeptrans:
                 ((Nat.nat, (Nat.nat, Nat.nat)),
                   (Option[Nat.nat], (Option[Nat.nat], Boolean))),
                x1: (List[((Nat.nat, (Nat.nat, Nat.nat)),
                            (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                      List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (keeptrans, x1) match {
  case (keeptrans, (transidval, transaction)) =>
    (keeptrans :: transidval, transaction)
}

def tidValidated(uu: (Nat.nat, (Nat.nat, Nat.nat)),
                  x1: List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]):
      Boolean
  =
  (uu, x1) match {
  case (uu, Nil) => false
  case (transid, (htransid, hvalue) :: ttrans) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](transid, htransid))
      true else tidValidated(transid, ttrans))
}

def keepHeaderSnd(keeptrans: ((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat),
                   x1: (List[((Nat.nat, (Nat.nat, Nat.nat)),
                               (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                         List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (keeptrans, x1) match {
  case (keeptrans, (transidval, transaction)) =>
    (transidval, keeptrans :: transaction)
}

def updateValsAck(x0: Option[Nat.nat], n: Nat.nat): Option[Nat.nat] = (x0, n)
  match {
  case (None, n) => Some[Nat.nat](n)
  case (Some(v), n) =>
    (if (Nat.less_eq_nat(v, n)) Some[Nat.nat](v) else Some[Nat.nat](n))
}

def updateValsPay(x0: Option[Nat.nat], n: Nat.nat): Option[Nat.nat] = (x0, n)
  match {
  case (None, n) => Some[Nat.nat](n)
  case (Some(v), n) =>
    (if (Nat.less_eq_nat(n, v)) Some[Nat.nat](v) else Some[Nat.nat](n))
}

def updateTransidvalsCancel(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                                  (Option[Nat.nat],
                                    (Option[Nat.nat], Boolean)))):
      ((Nat.nat, (Nat.nat, Nat.nat)),
        (Option[Nat.nat], (Option[Nat.nat], Boolean)))
  =
  x0 match {
  case (transid, (pay, (ack, test))) => (transid, (pay, (ack, false)))
}

def updateTransidvalsListCancel(x0: List[((Nat.nat, (Nat.nat, Nat.nat)),
   (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                                 transid: (Nat.nat, (Nat.nat, Nat.nat))):
      List[((Nat.nat, (Nat.nat, Nat.nat)),
             (Option[Nat.nat], (Option[Nat.nat], Boolean)))]
  =
  (x0, transid) match {
  case (Nil, transid) => List((transid, (None, (None, false))))
  case ((htransid, (hamc, (hamm, hisAvailable))) :: t, transid) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](htransid, transid))
      updateTransidvalsCancel((htransid, (hamc, (hamm, hisAvailable)))) :: t
      else (htransid, (hamc, (hamm, hisAvailable))) ::
             updateTransidvalsListCancel(t, transid))
}

def updateTransactionCancel(transid: (Nat.nat, (Nat.nat, Nat.nat)),
                             transidvals:
                               List[((Nat.nat, (Nat.nat, Nat.nat)),
                                      (Option[Nat.nat],
(Option[Nat.nat], Boolean)))],
                             x2: List[((Nat.nat, (Nat.nat, Nat.nat)),
Nat.nat)]):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (transid, transidvals, x2) match {
  case (transid, transidvals, Nil) => (transidvals, Nil)
  case (transid, transidvals, (htransid, hn) :: ttransaction) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](htransid, transid))
      (transidvals, ttransaction)
      else keepHeaderSnd((htransid, hn),
                          updateTransactionCancel(transid, transidvals,
           ttransaction)))
}

def updateTransactionBddCancel(transid: (Nat.nat, (Nat.nat, Nat.nat)),
                                x1: (List[((Nat.nat, (Nat.nat, Nat.nat)),
    (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                                      List[((Nat.nat, (Nat.nat, Nat.nat)),
     Nat.nat)])):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (transid, x1) match {
  case (transid, (transidvals, transaction)) =>
    updateTransactionCancel(transid, transidvals, transaction)
}

def updateTransidvalsPay(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                               (Option[Nat.nat], (Option[Nat.nat], Boolean))),
                          n: Nat.nat):
      ((Nat.nat, (Nat.nat, Nat.nat)),
        (Option[Nat.nat], (Option[Nat.nat], Boolean)))
  =
  (x0, n) match {
  case ((transid, (pay, (ack, test))), n) =>
    (if (test) (transid, (updateValsPay(pay, n), (ack, test)))
      else (transid, (pay, (ack, test))))
}

def updateTransidvalsListPay(x0: List[((Nat.nat, (Nat.nat, Nat.nat)),
(Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                              transid: (Nat.nat, (Nat.nat, Nat.nat)),
                              n: Nat.nat):
      List[((Nat.nat, (Nat.nat, Nat.nat)),
             (Option[Nat.nat], (Option[Nat.nat], Boolean)))]
  =
  (x0, transid, n) match {
  case (Nil, transid, n) => List((transid, (Some[Nat.nat](n), (None, true))))
  case ((htransid, (hamc, (hamm, hisAvailable))) :: t, transid, n) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](htransid, transid))
      updateTransidvalsPay((htransid, (hamc, (hamm, hisAvailable))), n) :: t
      else (htransid, (hamc, (hamm, hisAvailable))) ::
             updateTransidvalsListPay(t, transid, n))
}

def updateTransidvalsAck(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                               (Option[Nat.nat], (Option[Nat.nat], Boolean))),
                          n: Nat.nat):
      ((Nat.nat, (Nat.nat, Nat.nat)),
        (Option[Nat.nat], (Option[Nat.nat], Boolean)))
  =
  (x0, n) match {
  case ((transid, (pay, (ack, test))), n) =>
    (if (test) (transid, (pay, (updateValsAck(ack, n), test)))
      else (transid, (pay, (ack, test))))
}

def updateTransidvalsListAck(x0: List[((Nat.nat, (Nat.nat, Nat.nat)),
(Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                              transid: (Nat.nat, (Nat.nat, Nat.nat)),
                              n: Nat.nat):
      List[((Nat.nat, (Nat.nat, Nat.nat)),
             (Option[Nat.nat], (Option[Nat.nat], Boolean)))]
  =
  (x0, transid, n) match {
  case (Nil, transid, n) => List((transid, (None, (Some[Nat.nat](n), true))))
  case ((htransid, (hamc, (hamm, hisAvailable))) :: t, transid, n) =>
    (if (Product_Type.equal_proda[Nat.nat,
                                   (Nat.nat, Nat.nat)](htransid, transid))
      updateTransidvalsAck((htransid, (hamc, (hamm, hisAvailable))), n) :: t
      else (htransid, (hamc, (hamm, hisAvailable))) ::
             updateTransidvalsListAck(t, transid, n))
}

def updateTransaction(x0: List[((Nat.nat, (Nat.nat, Nat.nat)),
                                 (Option[Nat.nat],
                                   (Option[Nat.nat], Boolean)))],
                       transaction:
                         List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (x0, transaction) match {
  case (Nil, transaction) => (Nil, transaction)
  case (htransidvals :: ttransidvals, transaction) =>
    (if (validable(htransidvals, transaction))
      updateTransaction(ttransidvals, validate(htransidvals, transaction))
      else keepHeader(htransidvals,
                       updateTransaction(ttransidvals, transaction)))
}

def updateTransactionBdd(x0: (List[((Nat.nat, (Nat.nat, Nat.nat)),
                                     (Option[Nat.nat],
                                       (Option[Nat.nat], Boolean)))],
                               List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  x0 match {
  case (transidvals, transaction) => updateTransaction(transidvals, transaction)
}

def traiterMessage(x0: message,
                    x1: (List[((Nat.nat, (Nat.nat, Nat.nat)),
                                (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
                          List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])):
      (List[((Nat.nat, (Nat.nat, Nat.nat)),
              (Option[Nat.nat], (Option[Nat.nat], Boolean)))],
        List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)])
  =
  (x0, x1) match {
  case (Pay(tid, n), (transidvalsList, transaction)) =>
    (if (! (tidValidated(tid, transaction)))
      updateTransactionBdd((updateTransidvalsListPay(transidvalsList, tid, n),
                             transaction))
      else (transidvalsList, transaction))
  case (Ack(tid, n), (transidvalsList, transaction)) =>
    (if (! (tidValidated(tid, transaction)))
      updateTransactionBdd((updateTransidvalsListAck(transidvalsList, tid, n),
                             transaction))
      else (transidvalsList, transaction))
  case (Cancel(tid), (transidvalsList, transaction)) =>
    updateTransactionBddCancel(tid, (updateTransidvalsListCancel(transidvalsList,
                          tid),
                                      transaction))
}

} /* object tp89 */
